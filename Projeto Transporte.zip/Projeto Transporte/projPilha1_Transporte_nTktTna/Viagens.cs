﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projPilha1_Transporte_nTktTna
{
    class Viagens
    {
        List<Viagem> listaDeViagens;

        public List<Viagem> ListaDeViagens { get { return listaDeViagens; } set { listaDeViagens = value; } }

        public Viagens()
        {
            listaDeViagens = new List<Viagem>();
        }

        public bool incluirViagem(Viagem viagem)
        {
            ListaDeViagens.Add(viagem);
            return true;
        }
    }
}