﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projPilha1_Transporte_nTktTna
{
    class Garagem
    {
        int id;
        static int  temp=1;
        static int Incrementar()
        {
         return   temp++;
        }
       
        string local;
        Stack<Veiculo> pilhaDeVeiculos;
        
        public int Id { get { return id; } }
        public string Local { get { return local; } set { local = value; } }
        public Stack<Veiculo> PilhaVeiculos { get { return pilhaDeVeiculos; } set { pilhaDeVeiculos = value; } }
        
        public Garagem(int id) : this("")
        {
            
        }

        public Garagem(string local)
        {
            pilhaDeVeiculos = new Stack<Veiculo>();
            this.Local = local;
            this.id = Incrementar();        }

        public int qtdeVeiculos() {
            return pilhaDeVeiculos.Count();
        }
        
        public int potencialDeTransporte() {
            int potencial = 0;
            foreach (Veiculo v in pilhaDeVeiculos) {
                potencial += v.Lotacao;
            }
            return potencial;
        }

        public override bool Equals(object obj)
        {
            Garagem g = (Garagem)obj;
            return this.Local.Equals(g.Local);
        }
    }
}
